<?php
namespace ColitaliaRealEstate\Core;

/**
 * Property Manager Class
 * Questa classe è deprecata. La logica è stata spostata in /includes/Cpt/
 */
class PropertyManager {
    
    public function __construct() {
        // Tutta la logica è stata spostata per centralizzare il codice e risolvere i conflitti.
        // Questo file è mantenuto per evitare errori fatali se altre parti del codice lo richiamano.
    }
    
}