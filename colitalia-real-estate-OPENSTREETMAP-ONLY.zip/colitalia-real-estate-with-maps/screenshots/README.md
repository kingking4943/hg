# Screenshots

Per aggiungere screenshot al plugin:

1. Crea le immagini nelle seguenti dimensioni:
   - screenshot-1.png (1200x900) - Dashboard principale
   - screenshot-2.png (1200x900) - Gestione proprietà 
   - screenshot-3.png (1200x900) - Calendario prenotazioni
   - screenshot-4.png (1200x900) - Form prenotazione frontend
   - screenshot-5.png (1200x900) - Pannello impostazioni
   - screenshot-6.png (1200x900) - Widget Elementor

2. Carica le immagini in questa directory
3. Gli screenshot appariranno automaticamente nella pagina WordPress.org
